# Uneathening-The-Environmental-Impacts-of-Human-Activity-A-Global-Co2-Emission-Analysis



Dashboard public link-https://public.tableau.com/views/Co2dash_16812140139110/Dashboard1?:language=en-US&:display_count=n&:origin=viz_share_link


Story public link-https://public.tableau.com/views/Co2story_16812147714600/Co2Emissionstory?:language=en-US&:display_count=n&:origin=viz_share_link

Video demonstration link-https://drive.google.com/file/d/1-8CANnaqGL9haurFEdcSKNzpsfIpfTci/view?usp=drivesdk
